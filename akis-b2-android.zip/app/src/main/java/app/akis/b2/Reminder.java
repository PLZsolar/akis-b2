package app.akis.b2;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Reminder extends BroadcastReceiver {
    static final String CH = "daily";

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (a != null && (a.equals(Intent.ACTION_BOOT_COMPLETED) || a.equals("android.intent.action.MY_PACKAGE_REPLACED"))) {
            schedule(c);
            return;
        }
        SharedPreferences p = c.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        if (p.getBoolean("on", false)) {
            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            int done = today.equals(p.getString("day", "")) ? p.getInt("done", 0) : 0;
            int streak = p.getInt("streak", 0), min = p.getInt("dailyMin", 45);
            if (done < 4) {
                String title = streak > 0 ? "Akış B2 · " + streak + " gün seri" : "Akış B2";
                String body = done == 0 ? "Bugünkü " + min + " dakikalık İngilizce oturumun seni bekliyor." : (4 - done) + " adım kaldı, seriyi bozma.";
                show(c, title, body);
            }
        }
        schedule(c);
    }

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(CH, "Günlük hatırlatma", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Her gün belirlediğin saatte çalışma hatırlatması");
            nm.createNotificationChannel(ch);
        }
    }

    static void show(Context c, String title, String body) {
        ensureChannel(c);
        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(title).setContentText(body)
            .setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(pi);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(42, b.build());
    }

    static void schedule(Context c) {
        SharedPreferences p = c.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, Reminder.class).setAction("app.akis.b2.REMIND");
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        if (!p.getBoolean("on", false)) return;
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, p.getInt("h", 20));
        t.set(Calendar.MINUTE, p.getInt("m", 0));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= System.currentTimeMillis() + 1000) t.add(Calendar.DAY_OF_MONTH, 1);
        try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pi); }
        catch (SecurityException e) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pi); }
    }
}
